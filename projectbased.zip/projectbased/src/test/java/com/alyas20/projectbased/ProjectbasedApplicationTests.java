package com.alyas20.projectbased;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectbasedApplicationTests {

	@Test
	void contextLoads() {
	}

}
