package com.alyas20.projectbased;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectbasedApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectbasedApplication.class, args);
	}

}
