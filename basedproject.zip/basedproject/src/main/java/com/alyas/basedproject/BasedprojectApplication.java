package com.alyas.basedproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BasedprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(BasedprojectApplication.class, args);
	}

}
