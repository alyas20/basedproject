package com.alyas20.basedproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasedProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
